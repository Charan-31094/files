chrome.commands.onCommand.addListener((command) => {
    if (command === "send-selected-text") {
      chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        if (tabs.length > 0) {
          chrome.scripting.executeScript({
            target: {tabId: tabs[0].id},
            function: getSelectedText
          }, (injectionResults) => {
            if (chrome.runtime.lastError || !injectionResults || injectionResults.length === 0) {
              console.error('Error in executeScript:', chrome.runtime.lastError);
              return;
            }
            const selectedText = injectionResults[0].result;
            if (selectedText) {
              sendTextToServer(selectedText, tabs[0].id);
            } else {
              console.log("No text selected.");
            }
          });
        }
      });
    }
  });
  
  function getSelectedText() {
    return window.getSelection().toString();
  }
  
  function sendTextToServer(selectedText, tabId) {
    // Show loader
    chrome.scripting.executeScript({
        target: {tabId: tabId},
        function: showLoader
    });

    fetch('https://api.softpage.tech/api/extansbytext', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text: selectedText })
    })
    .then(response => response.json())
    .then(data => {
        chrome.scripting.executeScript({
            target: {tabId: tabId},
            function: removeLoader
        });

        console.log('Server response:', data.message);
        if (data.status) {
            chrome.scripting.executeScript({
                target: {tabId: tabId},
                function: dimScreen,
                args: [data.message]
            });
        }
    })
    .catch(error => {
        // Remove loader
        chrome.scripting.executeScript({
            target: {tabId: tabId},
            function: removeLoader
        });

        console.error('Error sending text to server:', error);
    });
}

function showLoader() {
    const loader = document.createElement('div');
    loader.id = 'loader';
    loader.style.position = 'fixed';
    loader.style.top = 0;
    loader.style.left = 0;
    loader.style.width = '100%';
    loader.style.height = '100%';
    loader.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    loader.style.zIndex = 1001;
    loader.style.display = 'flex';
    loader.style.justifyContent = 'center';
    loader.style.alignItems = 'center';
    loader.style.color = 'white';
    loader.style.fontSize = '20px';
    loader.innerText = 'Searching for answer...';
    document.body.appendChild(loader);
}

function removeLoader() {
    const loader = document.getElementById('loader');
    if (loader) {
        document.body.removeChild(loader);
    }
}

function dimScreen(message) {
  const overlay = document.createElement('div');
  overlay.style.position = 'fixed';
  overlay.style.top = 0;
  overlay.style.left = 0;
  overlay.style.width = '100%';
  overlay.style.height = '100%';
  overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
  overlay.style.zIndex = 1000;
  overlay.style.display = 'flex';
  overlay.style.justifyContent = 'center';
  overlay.style.alignItems = 'center';
  overlay.style.color = 'white';
  overlay.style.fontSize = '20px';
  overlay.innerText = message;
  document.body.appendChild(overlay);

  setTimeout(() => {
    document.body.removeChild(overlay);
  }, 2000); // Remove the overlay after 2 seconds
}
